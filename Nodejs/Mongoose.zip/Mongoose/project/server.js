const express = require("express")
const { connectMongoose,User } = require("./database")
const app = express()
app.use(express.json())
connectMongoose()
app.get('/',(req,res)=>{
  res.send("hello world")
})
app.post('/register',async (req,res)=>{
   const user = await User.findOne({username:req.body.username})
   if(user) return res.status(400).send("User already Exists")
   const newUser = await User.create(req.body)
   res.status(200).send(newUser)
})
app.post('/login',(req,res)=>{})
app.listen(3000,()=>{
    console.log("Listening to port 3000")
})